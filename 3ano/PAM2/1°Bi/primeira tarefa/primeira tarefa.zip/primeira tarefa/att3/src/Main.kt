package fundamentos
fun main(args: Array<String>) {
    imprimirSoma(4, 5)
}
fun imprimirSoma(a: Int, b: Int) {
    println(a+b)
}