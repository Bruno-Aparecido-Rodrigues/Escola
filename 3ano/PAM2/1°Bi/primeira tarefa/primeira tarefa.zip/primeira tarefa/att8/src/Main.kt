package fundamentos.controles
fun main(args: Array<String>) {
    val nota : Double = 8.3
    if(nota >= 7.0) {
        println("Aprovado")
    }
}