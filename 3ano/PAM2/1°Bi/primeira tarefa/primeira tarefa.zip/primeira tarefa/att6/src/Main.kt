package fundamentos
fun main(args: Array<String>) {
    val bomHumor = true
    print("Hoje estou ${if (bomHumor) "Feliz" else "chateado"}")
}