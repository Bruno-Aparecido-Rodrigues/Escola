package com.example.appnosql.model

data class CourseModel(
    // on below line we are creating variables for name and job
    var courseName: String,
    var courseDuration: String,
    var courseTracks: String,
    var courseDescription: String
)
