<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>dividepor4.php</title>
</head>
<body>
  <?php
    for($num=19;$num>1;$num--){
     if($num%4==0)
     echo 'O número '.$num.' é divisivel por 4 <br>';
    }
  ?> 
</body>
</html>