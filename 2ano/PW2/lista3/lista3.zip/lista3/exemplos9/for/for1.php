
<html lang="en">
<head>
     <meta charset="UTF-8">
     <title>for.php</title>
</head>
<body>
      <?php
        for ($i= 1; $i <= 5; $i++){
        echo $i.'<br/>';   
        }   
      ?>     
</body>
</html>