<html lang="en">
<head>
     <meta charset="UTF-8">
     <title>for2.php</title>
</head>
<body>
      <?php
        for ($i= 5; $i >= 1; $i--){
        echo $i.'<br/>';   
        }   
      ?>     
</body>
</html>