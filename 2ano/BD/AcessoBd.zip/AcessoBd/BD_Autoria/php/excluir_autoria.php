<html>
<head>   
<link rel="stylesheet" href="../css/stylesheet.css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script language=javascript>
           
           function blokletras(keypress)
           {
           //campo senha - bloqueia letras
           
              if(keypress>=48 && keypress<=57)
                 {
                     return true;
                 }
              else
                 {
                     return false;
                 }
              }  
          </script>      
</head>

<body class="louis_sera">
    <form name="cliente"  method = "POST" action = "">
    <div class='container'>
  <div class='card'>
    <h1>Exclusão de Livros publicados por editoras</h1>
    
    <div id='msgError'></div>
    <div id='msgSuccess'></div>
    
            <div class="label-float">
               <input name="txtcod_autor" type="text" id="codau" placeholder=" " data-mask="00" onkeypress="return blokletras(window.event.keyCode)" required>
               <label id="labelTitulo" for="titulo">Código do Autor</label>
            </div>

            <div class="label-float">
               <input name="txtcod_livro" type="text" id="codau" placeholder=" " data-mask="00" onkeypress="return blokletras(window.event.keyCode)" required>
               <label id="labelTitulo" for="titulo">Código do Livro</label>
            </div>

            <div class='justify-center'>
            <button name="btnenviar" type="submit" value="Cadastrar">Excluir</button>&nbsp;&nbsp;&nbsp;&nbsp;
            <button name="limpar" type="reset" value="Cadastrar">Limpar</button>
            </div>

    
  </div>
  </div>

  </form>
  <?php

extract ($_POST, EXTR_OVERWRITE); 
if (isset($btnenviar))
{
    include_once 'Autoria.php';
    $p= new Autoria();
    $p->setCod_livro($txtcod_livro);
    $p->setCod_Autor($txtcod_autor);
    if($p->validar()){
        echo "<h3>". $p->exclusao(). "</h3>";
        }else{
            header("location: teladeerro.html");} //chamada de método - o Sp é o parâmetro enviado 
}
    ?> 
          </form>
          <center>   <br><br><br><br>
          <a href = "menu.html"><button> Voltar </button></a>

          <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js"></script>
</body>
</html>