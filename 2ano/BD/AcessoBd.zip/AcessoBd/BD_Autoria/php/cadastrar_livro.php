<html>
<head>
<link rel="stylesheet" href="../css/stylesheet.css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script language=javascript>
           
           function blokletras(keypress)
           {
           //campo senha - bloqueia letras
           
              if(keypress>=48 && keypress<=57)
                 {
                     return true;
                 }
              else
                 {
                     return false;
                 }
              }  
          </script>  
</head>

<body class="john_marston">
    <form name="cliente"  method = "POST" action = "">
    <div class='container'>
  <div class='card'>
    <h1> Dados do Livro</h1>
    
    <div id='msgError'></div>
    <div id='msgSuccess'></div>
    
            <div class="label-float">
               <input name="txtitle" type="text" id="titulo" placeholder=" " required>
               <label id="labelTitulo" for="titulo">Título</label>
            </div>

            <div class="label-float">
               <input name="txtcate" type="text" id="categoria" placeholder=" " required>
               <label id="labelCategoria" for="categoria">Categoria</label>
            </div>

            <div class="label-float">
               <input name="txtisbn" type="text" id="isbn" placeholder=" " data-mask="000-00-0000-00-0" required>
               <label id="labelISBN" for="isbn">ISBN</label>
            </div>

            <div class="label-float">
               <input name="txtidioma" type="text" id="idioma" placeholder=" " required>
               <label id="labelIdioma" for="idioma">Idioma</label>
            </div>

            <div class="label-float">
               <input name="txtqtpag" type="text" id="qtpag" placeholder=" " data-mask="0000" onkeypress="return blokletras(window.event.keyCode)" required>
               <label id="labelqtpag" for="qtpag">QtdePag</label>
            </div>
            

            
            <div class='justify-center'>
            <button name="btnenviar" type="submit" value="Cadastrar">Cadastrar</button>&nbsp;&nbsp;&nbsp;&nbsp;
            <button name="limpar" type="reset" value="Cadastrar">Limpar</button>
            </div>

    
  </div>
  </div>

  </form>
     <?php
     extract($_POST, EXTR_OVERWRITE);
     if(isset($btnenviar))
      {
          include_once 'Livro.php';
          $pro=new Livro();
          $pro->setTitulo($txtitle);
          $pro->setCategoria($txtcate);
          $pro->setISBN($txtisbn);
          $pro->setIdioma($txtidioma);
          $pro->setQtdePag($txtqtpag);
          echo "<h3><br><br>" . $pro->salvar() . "</h3>";
      }
      ?>
      <br>
      <center>
      <a href = "menu.html"><button> Voltar </button></a>

      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js"></script>
   </body>
</html>

