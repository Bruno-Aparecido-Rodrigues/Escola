<html>
<head>   
<link rel="stylesheet" href="../css/stylesheet.css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">  
<script language=javascript>
           
           function blokletras(keypress)
           {
           //campo senha - bloqueia letras
           
              if(keypress>=48 && keypress<=57)
                 {
                     return true;
                 }
              else
                 {
                     return false;
                 }
              }  
          </script>    
</head>

<body>
    <form name="cliente"  method = "POST" action = "calt_autor2.php">
    <div class='container'>
  <div class='card'>
    <h1>Alteração de Autores Cadastrados</h1>
    
    <div id='msgError'></div>
    <div id='msgSuccess'></div>
    
            <div class="label-float">
               <input name="txtid" type="text" id="codau" placeholder=" " data-mask="00" onkeypress="return blokletras(window.event.keyCode)" required>
               <label id="labelTitulo" for="titulo">ID do Autor</label>
            </div>
            
            <div class='justify-center'>
            <button name="btnenviar" type="submit" value="Consultar">Consultar</button>&nbsp;&nbsp;&nbsp;&nbsp;
            <button name="limpar" type="reset" value="Limpar">Limpar</button>
            </div>

    
  </div>
  </div>

  </form>
          <center>   <br><br><br><br>
          <a href = "menu.html"><button> Voltar </button></a>

          <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js"></script>
</body>
</html>