<html>
<head>   
<link rel="stylesheet" href="../css/stylesheet.css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script language=javascript>
           
           function blokletras(keypress)
           {
           //campo senha - bloqueia letras
           
              if(keypress>=48 && keypress<=57)
                 {
                     return true;
                 }
              else
                 {
                     return false;
                 }
              }  
          </script>   
</head>

<body class="john_marston">
    <form name="cliente"  method = "POST" action = "">
    <div class='container'>
  <div class='card'>
    <h1> Dados Autoria</h1>
    
    <div id='msgError'></div>
    <div id='msgSuccess'></div>
    
            <div class="label-float">
               <input name="txtcoda" type="text" id="codau" placeholder=" " data-mask="00" onkeypress="return blokletras(window.event.keyCode)" required>
               <label id="labelTitulo" for="titulo">Código do Autor</label>
            </div>

            <div class="label-float">
               <input name="txtcodl" type="text" id="codli" placeholder=" " data-mask="00" onkeypress="return blokletras(window.event.keyCode)" required>
               <label id="labelCategoria" for="categoria">Código do Livro</label>
            </div>

            <div class="label-float">
               <input name="txtedit" type="text" id="ne" placeholder=" " required>
               <label id="labelISBN" for="isbn">Nome da Editora</label>
            </div>

            <div class="label-float">
               <input name="txtdatal" type="text" id="dtl" placeholder=" " data-mask="0000-00-00" required>
               <label id="labelIdioma" for="idioma">Data de Lançamento</label>
            </div>

            
            <div class='justify-center'>
            <button name="btnenviar" type="submit" value="Cadastrar">Cadastrar</button>&nbsp;&nbsp;&nbsp;&nbsp;
            <button name="limpar" type="reset" value="Cadastrar">Limpar</button>
            </div>

    
  </div>
  </div>

  </form>

     <?php
     extract($_POST, EXTR_OVERWRITE);
     if(isset($btnenviar))
      {
          include_once 'Autoria.php';
          $pro=new Autoria();
          $pro->setCod_autor($txtcoda);
          $pro->setCod_livro($txtcodl);
          $pro->setDatalancamento($txtdatal);
          $pro->setEditora($txtedit);
          echo "<h3><br><br>" . $pro->salvar() . "</h3>";
      }
      ?>
      <br>
      <center>
      <a href = "menu.html"><button> Voltar </button></a>

      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js"></script>
   </body>
</html>