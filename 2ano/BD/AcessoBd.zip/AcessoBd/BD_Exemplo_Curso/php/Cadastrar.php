  <html>
<head>   
<link rel="stylesheet" href="../css/stylesheet.css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">  
<script language=javascript>
           
           function blokletras(keypress)
           {
           //campo senha - bloqueia letras
           
              if(keypress>=48 && keypress<=57)
                 {
                     return true;
                 }
              else
                 {
                     return false;
                 }
              }  
          </script>
</head>

<body class="john_marston">
    <form name="cliente"  method = "POST" action = "">
    <div class='container'>
  <div class='card'>
    <h1> Dados do Produto</h1>
    
    <div id='msgError'></div>
    <div id='msgSuccess'></div>
    
            <div class="label-float">
               <input name="txtnome" type="text" id="codau" placeholder=" " required>
               <label id="labelTitulo" for="titulo">Nome do Produto</label>
            </div>

            <div class="label-float">
               <input name="txtestoq" type="text" id="codli" placeholder=" " data-mask="0000" onkeypress="return blokletras(window.event.keyCode)"
required>
               <label id="labelestoq" for="estoque">Estoque</label>
            </div>
            
            <div class='justify-center'>
            <button name="btnenviar" type="submit" value="Cadastrar">Cadastrar</button>&nbsp;&nbsp;&nbsp;&nbsp;
            <button name="limpar" type="reset" value="Cadastrar">Limpar</button>
            </div>

    
  </div>
  </div>

  </form>

     <?php
     extract($_POST, EXTR_OVERWRITE);
     if(isset($btnenviar))
      {
         include_once 'Produto.php';
          $pro=new Produto();
          $pro->setNome ($txtnome);
          $pro->setEstoque($txtestoq);
          echo "<h3><br><br>" . $pro->salvar() . "</h3>";
      }
      ?>
      <br>
      <center>
      <a href = "menu.html"><button> Voltar </button></a>

      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.js"></script>
   </body>
</html>