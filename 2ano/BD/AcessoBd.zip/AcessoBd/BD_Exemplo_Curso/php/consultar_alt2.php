<html>
<head>   
<link rel="stylesheet" href="../css/stylesheet.css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">  
</head>

<body>
    <form name="cliente"  method = "POST" action = "">
    <div class='container'>
  <div class='card'>
    <h1>Alteração de Produtos Cadastrados</h1>
    
    <?php
            $txtid=$_POST["txtid"];
            include_once 'Produto.php';
            $p = new Produto();
            $p->setId($txtid);
            $pro_bd=$p->alterar();
            
            
            if($pro_bd == "num tem"){
            header("location: teladeerro.html");
            }
        ?>

    <div id='msgError'></div>
    <div id='msgSuccess'></div>
    <?php
        foreach($pro_bd as $pro_mostrar)
        {

        ?>
            <div class="label-float">
               <input type="hidden" name="txtid" size="5" value='<?php echo $pro_mostrar[0]?>' id="codau">
               <label id="labelTitulo" for="titulo">ID do Produto <?php echo $pro_mostrar[0]?></label>
            </div>
            <br>
            <div class="label-float">
               <input name="txtnome" type="text" id="nomeau" value='<?php echo $pro_mostrar[1]?>'>
               <label id="labelTitulo" for="titulo">Nome do produto</label>
            </div>

            <div class="label-float">
               <input name="txtestoq" type="text" id="sobre" value='<?php echo $pro_mostrar[2]?>'>
               <label id="labelCategoria" for="categoria">estoque</label>
            </div>
            
            <div class='justify-center'>
            <button name="btnalterar" type="submit" value="Alterar">Alterar</button>
            <button name="limpar" type="reset" value="Limpar">Limpar</button>
            </div>

    
         </div>
        </div>
       <?php
        }        
         ?>
  </form>

     <?php
     extract($_POST, EXTR_OVERWRITE);
     if(isset($btnalterar))
      {
        include_once 'Produto.php';
        $pro = new Produto();
        $pro -> setNome($txtnome);
        $pro -> setEstoque($txtestoq);
        $pro -> setId($txtid);
        echo "<br><br><h3><center>" . $pro->alterar2() . "</h3>";
      }
      ?>
      <br>
      <center>
      <a href = "menu.html"><button> Voltar </button></a>
   </body>
</html>